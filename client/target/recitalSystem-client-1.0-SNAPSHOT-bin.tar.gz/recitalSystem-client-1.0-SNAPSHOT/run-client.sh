#!/bin/bash

java -cp 'lib/jars/*' "itba.pod.client.Client" $*

